﻿namespace PotterGame.Utils
{
    public interface ISecret
    {
        string GetClue();
    }
}