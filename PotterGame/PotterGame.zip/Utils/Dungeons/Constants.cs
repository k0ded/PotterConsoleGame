﻿namespace PotterGame.Utils.Dungeons
{
    public static class Constants
    {
        public const string tDungeon = "Tristan's Dungeon";
        public const string gDungeon = "Gringotts Vault 1337";
    }
}