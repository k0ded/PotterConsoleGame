﻿namespace PotterGame.Inventories.Items.ShopItems.OlivandersItems.Wands
{
    public struct Wand
    {
        public WandCores Core { get; set; }
        public WandWoods Wood { get; set; }
    }
}