﻿namespace PotterGame.Inventories.Items.ShopItems.OlivandersItems.Wands
{
    public enum WandCores
    {
        PHOENIX_FEATHER,
        DRAGON_HEARTSTRING,
        UNICORN_HAIR,
        THESTRAL_HAIR
    }
}