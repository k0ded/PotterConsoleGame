﻿namespace PotterGame.Inventories.Items.ShopItems.OlivandersItems.Wands
{
    public enum WandWoods
    {
        HOLLY, 
        VINE, 
        HAWTHORN,
        ASH,
        WILLOW,
        ELDER,
        CHERRY,
        YEW,
        WALNUT,
        FIR
    }
}